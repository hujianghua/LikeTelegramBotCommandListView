# Cache_Memory_File_DB_Demo
Create demo to show how to use memory、file and database cache for data.