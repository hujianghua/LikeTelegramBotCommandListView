//
//  ViewController.swift
//  Cache
//
//  Created by yunge on 2024/8/3.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.useCacheManager()
        
        self.useFileCacheManager()
        
        self.useUserDefaultsManager()
        
        self.useDBCacheManager()
    }


    // MARK: - CacheManager
    private func useCacheManager() {
        let image = UIImage(named: "xunhuan")
        CacheManager.shared.setValue(image!, forKey: "exampleKey")
        let cachedImage = CacheManager.shared.getValue(forKey: "exampleKey")
    }
    
    // MARK: - FileCacheManager
    private func useFileCacheManager() {
        let data = "example data".data(using: .utf8)!
        FileCacheManager.shared.save(data: data, forKey: "exampleKey")
        let cacheData = FileCacheManager.shared.load(forKey: "exampleKey")
    }
    
    // MARK: - UserDefaultsManager
    private func useUserDefaultsManager() {
        UserDefaultsManager.shared.set(value: "example Value", forKey: "exampleKey")
        let cacheValue = UserDefaultsManager.shared.get(forKey: "exampleKey")
    }
    
    // MARK: - useDBCacheManager
    private func useDBCacheManager() {
        let url = "www.baidu.com"
        let data = url.data(using: .utf8)!
        DBCacheManager.shared.saveData(urlString: url, data: data)
        
        if let cacheData = DBCacheManager.shared.fetchData(urlString: url),let cacheUrl = String(data: data, encoding: .utf8) {
            print(cacheUrl)
        }
    }
}

