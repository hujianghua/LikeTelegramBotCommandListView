//
//  CacheTool.swift
//  Cache
//
//  Created by yunge on 2024/8/3.
//

import Foundation

class CacheTool {

    static let shared = CacheTool()
    let cache = NSCache<NSString, NSString>()
    
    private init() {
        setup()
    }
    
    private func setup() {
        
    }
}
