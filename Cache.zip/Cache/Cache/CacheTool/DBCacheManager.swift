//
//  DBCacheManager.swift
//  Cache
//
//  Created by yunge on 2024/8/3.
//

import SQLite
import Foundation

class DBCacheManager {
    static let shared = DBCacheManager()
    
    private var db: Connection?
    
    private let table = Table("cache")
    private let id = Expression<Int64>("id")
    private let url = Expression<String>("url")
    private let data = Expression<Data>("data")
    private let expirationDate = Expression<Date>("expirationDate")
    
    private let cacheDuration: TimeInterval = 3600
    
    private init() {
        do {
            let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
            db = try Connection("\(path)/DBCache.sqlite3")
            
            try db?.run(table.create(temporary: false, ifNotExists: true, withoutRowid: false, block: { builder in
                builder.column(id, primaryKey: .autoincrement)
                builder.column(url, unique: true)
                builder.column(data)
                builder.column(expirationDate)
            }))
        } catch {
            print("数据库初始化失败：\(error)")
        }
    }

    func saveData(urlString: String, data: Data) {
        do {
            let expiration = Date().addingTimeInterval(cacheDuration)
            let insert = table.insert(or: .replace, self.url <- urlString, self.data <- data, self.expirationDate <- expiration)
            try db?.run(insert)
        } catch {
            print("保存数据失败:\(error)")
        }
    }
    
    func fetchData(urlString: String) -> Data? {
        do {
            let query = table.filter(self.url == urlString)
            if let cached = try db?.pluck(query) {
                let expiration = cached[self.expirationDate]
                if expiration > Date() {
                    return cached[self.data]
                } else {
                    try db?.run(query.delete())
                }
            }
        } catch {
            print("获取数据失败：\(error)")
        }
        return nil
    }
}
