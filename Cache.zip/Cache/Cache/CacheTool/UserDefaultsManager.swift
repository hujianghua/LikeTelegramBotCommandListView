//
//  UserDefaultsManager.swift
//  Cache
//
//  Created by yunge on 2024/8/3.
//

import Foundation

class UserDefaultsManager {
    static let shared = UserDefaultsManager()
    
    private init() {}
    
    func set(value: Any, forKey key: String) {
        UserDefaults.standard.set(value, forKey: key)
    }
    
    func get(forKey key: String) -> Any? {
        return UserDefaults.standard.object(forKey: key)
    }
    
    func remove(forKey key: String) {
        UserDefaults.standard.removeObject(forKey: key)
    }
}
