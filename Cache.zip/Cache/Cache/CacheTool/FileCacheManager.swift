//
//  FileCacheManager.swift
//  Cache
//
//  Created by yunge on 2024/8/3.
//

import UIKit

class FileCacheManager {
    static let shared = FileCacheManager()
    
    private init() {}
    
    func save(data: Data, forKey key: String) {
        let fileURL = getFileURL(forKey: key)
        try? data.write(to: fileURL)
    }
    
    func load(forKey key: String) -> Data? {
        let fileURL = getFileURL(forKey: key)
        return try? Data(contentsOf: fileURL)
    }
    
    func remove(forKey key: String) {
        let fileURL = getFileURL(forKey: key)
        try? FileManager.default.removeItem(at: fileURL)
    }
    
    private func getFileURL(forKey key: String) -> URL {
        let directory = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first!
        return directory.appendingPathComponent(key)
    }
}
