//
//  CacheManager.swift
//  Cache
//
//  Created by yunge on 2024/8/3.
//

import Foundation

class CacheManager {
    static let shared = CacheManager()
    
    private let cache = NSCache<NSString,AnyObject>()

    private init() {}
    
    func setValue(_ value: AnyObject, forKey key: String) {
        cache.setObject(value, forKey: key as NSString)
    }
    
    func getValue(forKey key: String) -> AnyObject? {
        cache.object(forKey: key as NSString)
    }
    
    func removeValue(forKey key: String) {
        cache.removeObject(forKey: key as NSString)
    }
    
    func removeAllValue() {
        cache.removeAllObjects()
    }
}
